def function2():
    return "Hello from module2!"