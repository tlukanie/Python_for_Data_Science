# Example: Import specific functions or classes
from .module1 import function1
from .module2 import function2