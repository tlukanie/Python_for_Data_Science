def function1():
    return "Hello from module1!"